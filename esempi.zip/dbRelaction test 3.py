# esempio con interfaccia ad oggetti 
#from Dbase import *
from dbase.Idbs import Idbs
from dbase.dbRelaction import dbRelaction
from dbase.Table import Table
from dbase.Field_type import *



class Agenda(Table):
    def __init__(self,table):
        super().__init__(table)
        self.Cognome=Field_string(30)
        self.Nome=Field_string(20)
        self.Telefono=Field_string(20)
        self.Email=Field_string(20)
        
        
    def __repr__(self):
        return "{} {} Telefono: {} Email: {}".format(self.Nome.value,
                self.Cognome.value,self.Telefono.value,self.Email.value)
persona1=Agenda('Agenda')
persona1.use()
persona2=Agenda('Agenda2')
persona2.use()

idb1=Idbs(persona1,"Cognome1.index")
idb2=Idbs(persona2,"Cognome2.index")
idb1.index(persona1.Cognome)
idb2.index(persona2.Cognome)
dbr1=dbRelaction(idb1,idb2)

if "Paolino" in dbr1:
    print("in db1 {} {}".format(persona1.Cognome.value,persona1.Nome.value)) ###

            
else:
    print("Chiave non presente")
    
    
        
