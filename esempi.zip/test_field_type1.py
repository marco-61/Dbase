from dbase.Table import Table
from dbase.Field_type import *
from dbase.Date import Date
from dbase.dbs import dbs

class test(Table):
    def __init__(self,table):
        super().__init__(table)
        self.Nome=Field_string(30)
        self.Carattere=Field_char(valid_char=('m,f','f'))
        self.Eta=Field_int(Range=(0,150,0))
        self.Complesso=Field_complex(Range=(2+3j,7+0j,5+3j))
        self.Float=Field_float(Range=(4.0,7.0,5.3))
        self.Intero=Field_int(Range=(5,25))
        self.Boolean=Field_bool()
        self.List=Field_list()
        self.Tuple=Field_tuple()
        self.Set=Field_set()
        self.Dict=Field_dict()
        self.Date=Field_date()
       
        

d=Date.today()
User=test('test')

User.append_blank()


User.Nome.value='Topolino'
User.Carattere.value="mio"
User.Eta.value=50
User.Complesso.value=(2+3j)
User.Float.value=(6.5)
User.Intero.value=5
User.Boolean.value=True
User.List.value=[4,5,6]
User.Tuple.value=(4,8)
User.Set.value={1,2,3}
User.Dict.value={1:3,5:6}
User.Date.value=d

print("Nome =",User.Nome)
print("Carattere =",User.Carattere)
print("Eta =",User.Eta)
print("Complesso =",User.Complesso)
print("Float =",User.Float)
print("Intero =",User.Intero)
print("Boolean =",User.Boolean)
print("List =",User.List)
print("Tuple =",User.Tuple)
print("Set =",User.Set)
print("Dict =",User.Dict)
print("Date =",User.Date)
    
    
    
   
          
    
