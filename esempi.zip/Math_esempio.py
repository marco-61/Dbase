from dbase.Table import *
from dbase.Field_type import *
from dbase.dbMath import dbMath
import random 

class Math_Es(Table):
    def __init__(self,table):
        super().__init__(table)
        self.Integer=Field_int()
        self.Float=Field_float()
        self.Complex=Field_complex()
        self.Rinteger=Field_int(Range=(3,1200,0))
    def __str__(self):
        return "Totale Integer={} - Totale Float={} - Totale Complex={} - Totale Integer(3,350,0)={}:".format(self.Integer.value,
                self.Float.value,self.Complex.value,self.Rinteger.value)
    
db=Math_Es('Math_es')

for i in range(10): # riempio il database con valori a caso
    db.append_blank()
    db.Integer.value= random.randrange(7,77)
    db.Float.value= random.randrange(45,176.0)*0.1567
    db.Complex.value= random.randrange(8,100.0)*(6+62j)
    db.Rinteger.value= random.randrange(3,1200)
    
m=dbMath(db)
print('Totale Integer={}'.format(m.total(db.Integer)))
print('Totale Float={}'.format(m.total(db.Float)))      
print('Totale Complex={}'.format(m.total(db.Complex)))
print('Totale Integer(3,1200,0)={}'.format(m.total(db.Rinteger)))
print('_'*50)
print('Max Integer={}'.format(m.max(db.Integer)))
print('Max Float={}'.format(m.max(db.Float)))      
print('Max Complex={}'.format(m.max(db.Complex)))
print('Max Integer(3,1200,0)={}'.format(m.max(db.Rinteger)))
print('_'*50)
print('Min Integer={}'.format(m.min(db.Integer)))
print('Min Float={}'.format(m.min(db.Float)))      
print('Min Complex={}'.format(m.min(db.Complex)))
print('Min Integer(3,1200,0)={}'.format(m.min(db.Rinteger)))
print('_'*50)
print('Average Integer={}'.format(m.average(db.Integer)))
print('Average Float={}'.format(m.average(db.Float)))      
print('Average Complex={}'.format(m.average(db.Complex)))
print('Average Integer(3,1200,0)={}'.format(m.average(db.Rinteger)))
      
                                    
      
      
      

    

        
        
