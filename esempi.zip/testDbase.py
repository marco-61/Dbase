from dbase.Shared import Shared
from dbase.Table import *
from dbase.Field_type import *
from dbase.Idbs import Idbs
from dbase.dbs import dbs


class Agenda(Table):
    def __init__(self,table):
        super().__init__(table)
        self.Cognome=Field_string(30)
        self.Nome=Field_string(20)
        self.Telefono=Field_string(20)
        self.Email=Field_string(20)      
    def __str__(self):
        return "{} {} - Telefono: {} - Email: {}".format(self.Nome.value,
                self.Cognome.value,self.Telefono.value,self.Email.value)


persona=Agenda('Agenda')
persona.use()
ind=Idbs(persona,"Agenda-Cognome.index")
ind2=Idbs(persona,"Agenda-Cognome-Nome.index")
ind.index(persona.Cognome)
ind2.index(persona.Cognome,persona.Nome)
persona.seek_to_start()
print('Chiave singola "Paolino"\n')
if "Paolino" in ind:
    print(persona)
    while ind.next():
       print(persona)
else:
    print("Chiave non presente") # ricerca non senza esiti

print('Chiave singola parziale doppia parziale "De*2\n')
if "De*" in ind:
    print(persona)
    ciclo=True
    while ciclo:
        if ind.next():
            print(persona)
        else:
            print("*****Non ci sono altre corrispondenze*****")
            ciclo=False

else:
    print("Chiave non presente")


print('Chiave Doppia  "Paolino-Paperino"\n')
if "Paolino-Paperino" in ind2:
    print(persona)
    ciclo=True
    while ciclo:
        if ind.next():
            print(persona)
        else:
            print("\n*****Non ci sono altre corrispondenze*****")
            ciclo=False

else:
    print("Chiave non presente")

print('Chiave doppia parziale "Paolino*"\n')
if "Paolino*" in ind:
    print(persona)
    ciclo=True
    while ciclo:
        if ind.next():
            print(persona)
        else:
            print("\n*****Non ci sono altre corrispondenze*****")
            ciclo=False

else:
    print("Chiave non presente")
    
#from search import search
def filtro(err):
    print(persona) if err else print("Chiave non presente")
    return
print('\nRicerca tramite callback chiave "De*"\n')
ind.search('De*',filtro)
print('\nInserisco una chiave errata "Di*"')
ind.search('Di*',filtro)
