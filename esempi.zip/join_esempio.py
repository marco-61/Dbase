from dbase.Shared import Shared
from dbase.Table import *
from dbase.Field_type import *
from dbase.join import join


class Agenda(Table):
    def __init__(self,table):
        super().__init__(table)
        self.Cognome=Field_string(30)
        self.Nome=Field_string(20)
        self.Telefono=Field_string(20)
        self.Email=Field_string(20)      
    def __str__(self):
        return "{} {} - Telefono: {} - Email: {}".format(self.Nome.value,
                self.Cognome.value,self.Telefono.value,self.Email.value)


def Filtro(f1,f2):
    if f1.value=='Paolino':f2.value='Quack'
    return True
persona=Agenda('Agenda')
persona.use()
p2=Agenda('Agenda2')
print('Record in Agenda\n')
persona.seek_to_start() # mostro i campi nel primo database
while not persona.eof():
    print(persona)
    persona.next()
    
print('\nCopio i record in Agenda2\n') #copio l'intero database dal primo al secondo database
persona.seek_to_start()
p2.seek_to_start()
join([persona.Cognome,persona.Nome,persona.Telefono,persona.Email],[p2.Cognome,p2.Nome,p2.Telefono,p2.Email])

while not p2.eof():
    print(p2)
    p2.next()
print('\nCopio con filtro i record in Agenda2\n')
persona.seek_to_start() #soprascrivo il secondo database con il primo effetuando un filtaggio
p2.seek_to_start()
join([persona.Cognome,persona.Nome,persona.Telefono,persona.Email],[p2.Cognome,p2.Nome,p2.Telefono,p2.Email],Filter=Filtro)
#p2.seek_to_start()
while not p2.eof():
    print(p2)
    p2.next()   
